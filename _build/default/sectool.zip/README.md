# cs3110-sectool
This is our final project for CS 3110, and it is intended to be a security tool implementing ECC and AES.
